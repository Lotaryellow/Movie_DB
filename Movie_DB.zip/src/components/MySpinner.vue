<template>
  <img src="../../public/img/spinner.gif" alt="" />
</template>
<script>
export default {};
</script>
<style lang="scss"></style>
